#ifndef ps3d_motion_parameters_h
#define ps3d_motion_parameters_h

class PS3dMotionParameters
{
public:
    virtual bool isYSymmetric() = 0;
};

#endif
